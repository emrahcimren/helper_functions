**Helper Functions**
=================

This repo provides helper functions for

- Listing files in a directory

Installation
------------

```
pip install cimren-helpers
```

How to use
----------

```
from helpers import files

file_list = files.get_all_files_in_directory('.')
```
